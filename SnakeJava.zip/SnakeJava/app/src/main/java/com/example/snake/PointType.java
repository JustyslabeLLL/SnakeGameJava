package com.example.snake;

public enum PointType {
    EMPTY, SNAKE, APPLE
}
