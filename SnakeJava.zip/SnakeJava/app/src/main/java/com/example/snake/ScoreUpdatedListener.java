package com.example.snake;

public interface ScoreUpdatedListener {
    void onScoreUpdated(int score);
}
